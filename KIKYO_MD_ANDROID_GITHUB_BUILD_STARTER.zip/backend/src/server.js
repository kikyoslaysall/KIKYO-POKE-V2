'use strict';

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const PORT = Number(process.env.PORT || process.env.SERVER_PORT || 3000);
const HOST = '0.0.0.0';
const DATA_DIR = path.join(__dirname, '..', 'data');
const DB_FILE = path.join(DATA_DIR, 'store.json');
const API = '/api/v1';

fs.mkdirSync(DATA_DIR, { recursive: true });

if (!fs.existsSync(DB_FILE)) {
  fs.writeFileSync(DB_FILE, JSON.stringify({
    trainers: {},
    sessions: {},
    world: {
      region: 'Kanto',
      weather: 'Clear',
      timeOfDay: 'Day',
      events: []
    }
  }, null, 2));
}

function readStore() {
  return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
}

function writeStore(store) {
  const tmp = DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(store, null, 2));
  fs.renameSync(tmp, DB_FILE);
}

function json(res, status, body) {
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store'
  });
  res.end(JSON.stringify(body));
}

function error(res, status, code, message) {
  json(res, status, { error: { code, message } });
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = '';

    req.on('data', chunk => {
      raw += chunk;
      if (raw.length > 1000000) req.destroy();
    });

    req.on('end', () => {
      if (!raw) return resolve({});

      try {
        resolve(JSON.parse(raw));
      } catch {
        reject(new Error('Invalid JSON body'));
      }
    });

    req.on('error', reject);
  });
}

function token() {
  return crypto.randomBytes(32).toString('hex');
}

function safeEqual(a, b) {
  const aa = Buffer.from(String(a));
  const bb = Buffer.from(String(b));

  return aa.length === bb.length &&
    crypto.timingSafeEqual(aa, bb);
}

function getTrainer(req) {
  const h = req.headers.authorization || '';

  if (!h.startsWith('Bearer ')) return null;

  const supplied = h.slice(7);
  const store = readStore();
  const session = store.sessions[supplied];

  if (!session || session.expiresAt < Date.now()) return null;

  const trainer = store.trainers[session.trainerId];

  return trainer ? { store, trainer, supplied } : null;
}

function requireAuth(req, res) {
  const auth = getTrainer(req);

  if (!auth) {
    error(res, 401, 'UNAUTHORIZED',
      'A valid bearer access token is required.');
    return null;
  }

  return auth;
}

function notReady(res, feature) {
  error(res, 501, 'GAME_ENGINE_NOT_CONNECTED',
    `${feature} is not connected to a KIKYO game engine yet. This API starter does not invent game data or rewards.`);
}

const server = http.createServer(async (req, res) => {
  const url = new URL(
    req.url,
    `http://${req.headers.host || 'localhost'}`
  );

  const p = url.pathname;

  if (req.method === 'GET' && p === '/health') {
    return json(res, 200, {
      ok: true,
      service: 'KIKYO MD App API',
      version: '1.0.0',
      timestamp: new Date().toISOString()
    });
  }

  if (req.method === 'GET' && p === `${API}/health`) {
    return json(res, 200, {
      ok: true,
      api: 'v1',
      timestamp: new Date().toISOString()
    });
  }

  if (!p.startsWith(API)) {
    return error(res, 404, 'NOT_FOUND', 'Route not found.');
  }

  let body;

  try {
    if (['POST', 'PUT', 'PATCH'].includes(req.method)) {
      body = await readBody(req);
    }
  } catch {
    return error(res, 400, 'BAD_JSON',
      'Request body must be valid JSON.');
  }

  if (req.method === 'POST' && p === `${API}/auth/request-otp`) {
    return error(res, 503, 'OTP_PROVIDER_NOT_CONFIGURED',
      'Sign-in is not enabled yet. Configure and verify an OTP delivery provider before allowing real accounts to sign in.');
  }

  if (req.method === 'POST' && p === `${API}/auth/verify-otp`) {
    return error(res, 503, 'OTP_PROVIDER_NOT_CONFIGURED',
      'OTP verification is not enabled until a trusted delivery provider and account lookup are configured.');
  }

  if (req.method === 'POST' && p === `${API}/auth/refresh`) {
    return error(res, 501, 'REFRESH_NOT_CONFIGURED',
      'Refresh-token rotation will be enabled with production authentication.');
  }

  const auth = requireAuth(req, res);
  if (!auth) return;

  const { trainer, store } = auth;

  if (req.method === 'GET' && p === `${API}/me`) {
    return json(res, 200, {
      trainer: {
        id: trainer.id,
        displayName: trainer.displayName,
        level: trainer.level,
        badges: trainer.badges,
        currency: trainer.currency,
        guild: trainer.guild
      }
    });
  }

  if (req.method === 'GET' && p === `${API}/pokemon/collection`) {
    return json(res, 200, {
      party: trainer.party || [],
      pc: trainer.pc || [],
      pokedex: trainer.pokedex || {
        seen: 0,
        caught: 0
      },
      source: 'starter-profile'
    });
  }

  if (req.method === 'GET' && p === `${API}/inventory`) {
    return json(res, 200, {
      items: trainer.items || [],
      balls: trainer.balls || []
    });
  }

  if (req.method === 'GET' && p === `${API}/world`) {
    return json(res, 200, store.world);
  }

  if (req.method === 'GET' && p === `${API}/regions`) {
    return json(res, 200, {
      regions: ['Kanto', 'Johto', 'Hoenn', 'Sinnoh']
        .map(name => ({
          name,
          unlocked: name === 'Kanto'
        }))
    });
  }

  if (req.method === 'GET' && p === `${API}/battles`) {
    return json(res, 200, {
      available: [],
      message: 'Battle engine is not connected yet.'
    });
  }

  if (req.method === 'GET' && p === `${API}/pve/progress`) {
    return json(res, 200, {
      leaders: [],
      message: 'PvE engine is not connected yet.'
    });
  }

  if (req.method === 'GET' && p === `${API}/raids`) {
    return json(res, 200, {
      raids: [],
      message: 'Raid engine is not connected yet.'
    });
  }

  if (req.method === 'GET' && p === `${API}/league`) {
    return json(res, 200, {
      season: null,
      ranking: [],
      rewards: [],
      message: 'League engine is not connected yet.'
    });
  }

  if (req.method === 'GET' && p === `${API}/guild`) {
    return json(res, 200, {
      guild: trainer.guild || null
    });
  }

  if (req.method === 'POST' && p === `${API}/pokemon/party`) {
    if (
      !Array.isArray(body.party) ||
      body.party.length > 6 ||
      body.party.some(x =>
        typeof x !== 'string' || x.length > 80
      )
    ) {
      return error(res, 400, 'INVALID_PARTY',
        'party must be an array of up to six Pokémon identifiers.');
    }

    return notReady(res, 'Party updates');
  }

  if (
    req.method === 'POST' &&
    /^\/api\/v1\/battles\/[^/]+\/(actions|forfeit)$/.test(p)
  ) {
    return notReady(res, 'Battle actions');
  }

  return error(res, 404, 'NOT_FOUND', 'API route not found.');
});

server.listen(PORT, HOST, () => {
  console.log(`KIKYO MD App API listening on ${HOST}:${PORT}`);
  console.log('Health check: /health');
  console.log('API prefix: /api/v1');
});

process.on('SIGTERM', () =>
  server.close(() => process.exit(0))
);

process.on('SIGINT', () =>
  server.close(() => process.exit(0))
);