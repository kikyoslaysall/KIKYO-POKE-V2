# KIKYO MD Android — player app project

A lightweight native Android project for the KIKYO Pokémon game. The current build is a polished **preview interface** and backend integration scaffold.

## Included in this project

- Dark anime-inspired KIKYO MD home screen and bottom navigation.
- Pokémon collection, party/PC, Pokédex and inventory entry points.
- Kanto, Johto, Hoenn and Sinnoh exploration pages.
- Battle centre entry points for PvP, the 11 PvE leaders, raids and league seasons.
- Trainer profile and shared-account information panels.
- Native Android UI with no third-party runtime libraries.
- HTTPS-only network permission and a central API configuration placeholder.
- `BACKEND_API_SPEC.md` describing the server endpoints and shared-profile requirements.

## Compatibility target

- Minimum Android: 10 (API 29).
- Compile/target SDK: 36.
- Java/Kotlin target: 17.
- Android 17/18 cannot be certified in advance. Test on actual devices and their final SDKs when available.

## Important: this is not yet a working live-game APK

The screens are in preview mode. No live sign-in, Pokémon data, inventory, battles, PvE progress, raids, rewards, WhatsApp/Telegram sync or Pterodactyl connection is active yet. Those features require a working public HTTPS API on the KIKYO game server. See `BACKEND_API_SPEC.md`.

The API must use the same canonical trainer record as WhatsApp and Telegram. The three master-owner numbers should be mapped to the one canonical master profile on the server. Never put Pterodactyl credentials, WhatsApp session files or private bot tokens inside this app.

## Build an APK on a computer with Android Studio

1. Install Android Studio and JDK 17.
2. Extract this ZIP.
3. In Android Studio, choose **Open** and select the extracted `KikyoMD_Android_Starter` folder (the folder containing `settings.gradle.kts`).
4. Allow Gradle sync to finish and install any requested Android SDK components.
5. Choose **Build → Generate Signed Bundle / APK → APK** to create a signed release APK.
6. Install and test the APK on Android 10 or newer.

## APK size

The project has no third-party runtime dependencies and enables release shrinking. The requested 5–8 MB is a target only; the actual APK size can only be confirmed after a release build is produced and measured.

## What is still needed to finish live integration

The backend source/project (or API documentation), a public HTTPS API base URL, and a safe test account. The Android app can then be connected without exposing server credentials. Do not send passwords, OTPs, session files or private tokens in chat.
