# Build status — 18 November 2026

- Android project source: prepared.
- UI preview: implemented.
- API contract: documented; server implementation not supplied.
- Live account login and game data: not connected.
- APK: not compiled or device-tested in this environment (Android SDK/Gradle build tools are not installed here).
- Android 10 minimum: configured in Gradle (`minSdk 29`).
- Android 17/18: not certified; future SDK/device testing required.
- APK size: not measured; 5–8 MB remains a target, not a guarantee.
