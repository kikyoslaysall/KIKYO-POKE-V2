package com.kikyo.md

/** Public HTTPS API base URL is injected at build time; never put panel credentials here. */
object ApiConfig {
    const val BASE_URL: String = BuildConfig.API_BASE_URL
    const val API_VERSION = "/api/v1"
    val IS_CONFIGURED: Boolean get() = BASE_URL.startsWith("https://")
}
