package com.kikyo.md

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*
import android.os.Handler
import android.os.Looper

/** KIKYO MD player app shell. Live game data is intentionally not fabricated. */
class MainActivity : Activity() {
    private val bg = Color.rgb(9, 11, 20)
    private val panel = Color.rgb(22, 26, 43)
    private val panel2 = Color.rgb(30, 35, 56)
    private val muted = Color.rgb(159, 169, 194)
    private val accent = Color.rgb(183, 112, 255)
    private val cyan = Color.rgb(89, 215, 224)
    private lateinit var body: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        showIntro()
    }

    private fun showIntro() {
        val intro = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(bg)
            alpha = 0f
        }
        val mark = TextView(this).apply {
            text = "KIKYO"
            textSize = 38f
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            setTextColor(Color.WHITE)
            letterSpacing = 0.18f
        }
        val sub = TextView(this).apply {
            text = "M D   •   P O K É M O N   W O R L D"
            textSize = 10f
            setTextColor(cyan)
            gravity = Gravity.CENTER
        }
        intro.addView(mark)
        intro.addView(sub)
        setContentView(intro)
        mark.scaleX = 0.82f; mark.scaleY = 0.82f
        intro.animate().alpha(1f).setDuration(450).start()
        mark.animate().scaleX(1f).scaleY(1f).setDuration(650).start()
        Handler(Looper.getMainLooper()).postDelayed({ home() }, 1050)
    }

    private fun showScreen(view: View) {
        view.alpha = 0f
        view.translationY = dp(12).toFloat()
        setContentView(view)
        view.animate().alpha(1f).translationY(0f).setDuration(280).start()
    }

    private fun shell(active: String = "Home"): LinearLayout {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(17), dp(16), dp(17), dp(7))
        }
        val scroll = ScrollView(this).apply { isFillViewport = true; overScrollMode = View.OVER_SCROLL_NEVER }
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(body)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(5), 0, 0)
        }
        listOf("Home", "Dex", "Battle", "Profile").forEach { label ->
            val b = TextView(this).apply {
                text = (if (active == label) "●  " else "") + label
                textSize = 11f
                gravity = Gravity.CENTER
                setTextColor(if (active == label) accent else muted)
                setPadding(dp(4), dp(12), dp(4), dp(12))
                setOnClickListener {
                    when (label) {
                        "Home" -> home()
                        "Dex" -> dex()
                        "Battle" -> battles()
                        else -> profile()
                    }
                }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        outer.addView(nav)
        return outer
    }

    private fun home() {
        showScreen(shell("Home"))
        rowHeader()
        body.addView(space(16))
        val hero = card(true)
        hero.addView(label("KIKYO TRAINER NETWORK", 10f, cyan, true))
        hero.addView(space(8))
        hero.addView(label("Your next\nPokémon adventure.", 29f, Color.WHITE, true))
        hero.addView(space(8))
        hero.addView(label("Explore regions, build your team and challenge powerful trainers.", 13f, muted, false))
        hero.addView(space(16))
        hero.addView(pill("PLAYER APP  •  PREVIEW", accent))
        body.addView(hero)
        body.addView(space(18))
        sectionTitle("YOUR WORLD", "Choose where to go")
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listOf(
            arrayOf("Pokémon collection", "Party, PC storage and Pokédex", "dex"),
            arrayOf("Explore regions", "Kanto • Johto • Hoenn • Sinnoh", "explore"),
            arrayOf("PvE gyms & raids", "Boss challenges and legendary raids", "pve"),
            arrayOf("PvP battles", "Challenge another trainer", "battle"),
            arrayOf("League & guilds", "Ranks, seasons and team play", "league"),
            arrayOf("Quests & rewards", "Daily tasks and adventure progress", "quests")
        ).chunked(2).forEach { pair ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEach { item ->
                val c = card(false).apply {
                    addView(label(iconFor(item[2]), 21f, accent, true))
                    addView(space(6))
                    addView(label(item[0], 14f, Color.WHITE, true))
                    addView(label(item[1], 11f, muted, false))
                    setOnClickListener { open(item[2]) }
                }
                val lp = LinearLayout.LayoutParams(0, dp(126), 1f)
                lp.setMargins(dp(3), dp(3), dp(3), dp(3))
                line.addView(c, lp)
            }
            if (pair.size == 1) line.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            grid.addView(line)
        }
        body.addView(grid)
        body.addView(space(15))
        val status = card(false)
        status.addView(label("SERVER STATUS", 10f, cyan, true))
        status.addView(space(5))
        status.addView(label("Waiting for secure game API", 15f, Color.WHITE, true))
        status.addView(label("This preview is not connected to your live KIKYO database yet. Your Pokémon and progress will appear after backend connection.", 11f, muted, false))
        body.addView(status)
        body.addView(space(12))
        body.addView(label("KIKYO MD  •  PLAYER CLIENT", 9f, muted, false).apply { gravity = Gravity.CENTER })
    }

    private fun rowHeader() {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left.addView(label("KIKYO MD", 22f, Color.WHITE, true))
        left.addView(label("POKÉMON WORLD", 9f, accent, true))
        r.addView(left, LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(pill("OFFLINE PREVIEW", cyan))
        body.addView(r)
    }

    private fun dex() {
        showScreen(shell("Dex")); pageHeader("Pokémon", "Your collection and Pokédex")
        infoCard("COLLECTION", "Your caught Pokémon, party and PC storage will sync from the shared KIKYO game profile.")
        sectionTitle("QUICK ACTIONS", "Collection tools")
        actionCard("My party", "View and arrange your active team")
        actionCard("PC storage", "Manage Pokémon stored in your boxes")
        actionCard("Pokédex", "Discover Pokémon across all four regions")
        actionCard("Pokémon details", "Stats, types, moves and abilities")
        note("No sample Pokémon are shown as owned. Live records will load after the game API is connected.")
    }

    private fun battles() {
        showScreen(shell("Battle")); pageHeader("Battle grounds", "Choose your challenge")
        actionCard("Player vs Player", "Battle another trainer when matchmaking is connected")
        actionCard("PvE gym leaders", "Progress through the 11 gym challenges")
        actionCard("Legendary raids", "Team up for special boss encounters")
        actionCard("Battle records", "Wins, losses and battle history")
        note("Battle actions are currently preview screens only. No battle is started from this version.")
    }

    private fun profile() {
        showScreen(shell("Profile")); pageHeader("Trainer profile", "One shared profile across supported platforms")
        infoCard("ACCOUNT LINKING", "The Android app is planned to use the same trainer profile as your WhatsApp and Telegram game accounts.")
        actionCard("Link phone number", "Account verification will be added with the secure API")
        actionCard("Trainer progress", "Level, badges, coins and achievements")
        actionCard("Settings", "Notifications, privacy and app preferences")
        note("Your account is not logged in yet. Do not enter passwords or server panel credentials in this preview.")
    }

    private fun open(which: String) {
        when (which) {
            "dex" -> dex()
            "battle", "pve" -> battles()
            else -> {
                showScreen(shell("Home"))
                val title = when (which) { "explore" -> "Explore regions"; "league" -> "League & guilds"; else -> "Quests & rewards" }
                pageHeader(title, "KIKYO Pokémon adventure")
                when (which) {
                    "explore" -> listOf("Kanto", "Johto", "Hoenn", "Sinnoh").forEach { actionCard(it, "Regional encounters and exploration") }
                    "league" -> { actionCard("Trainer league", "Season ranks and competitive progress"); actionCard("Guilds", "Groups, roles and shared activities") }
                    else -> { actionCard("Daily quests", "Tasks and daily rewards"); actionCard("Achievements", "Milestones from your adventure") }
                }
                note("This section will display live game data after backend integration.")
            }
        }
    }

    private fun pageHeader(title: String, subtitle: String) {
        body.addView(label("KIKYO MD", 12f, accent, true)); body.addView(space(14))
        body.addView(label(title, 27f, Color.WHITE, true)); body.addView(label(subtitle, 12f, muted, false)); body.addView(space(16))
    }

    private fun sectionTitle(kicker: String, title: String) {
        body.addView(label(kicker, 9f, accent, true)); body.addView(label(title, 18f, Color.WHITE, true)); body.addView(space(7))
    }

    private fun infoCard(title: String, message: String) {
        val c = card(true); c.addView(label(title, 10f, cyan, true)); c.addView(space(7)); c.addView(label(message, 14f, Color.WHITE, false)); body.addView(c); body.addView(space(13))
    }

    private fun actionCard(title: String, description: String) {
        val c = card(false); c.addView(label(title, 15f, Color.WHITE, true)); c.addView(label(description, 11f, muted, false)); body.addView(c); body.addView(space(8))
    }

    private fun note(message: String) {
        body.addView(space(6)); body.addView(label(message, 11f, muted, false))
    }

    private fun card(featured: Boolean) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(15), dp(14), dp(15), dp(14))
        background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
            if (featured) intArrayOf(Color.rgb(43, 30, 67), Color.rgb(22, 29, 49)) else intArrayOf(panel2, panel)).apply {
            cornerRadius = dp(17).toFloat(); setStroke(dp(1), Color.rgb(53, 57, 82))
        }
    }

    private fun pill(text: String, color: Int) = TextView(this).apply {
        this.text = text; textSize = 9f; typeface = Typeface.DEFAULT_BOLD; setTextColor(color)
        setPadding(dp(9), dp(6), dp(9), dp(6))
        background = GradientDrawable().apply { setColor(Color.rgb(35, 37, 59)); cornerRadius = dp(20).toFloat(); setStroke(dp(1), color) }
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); setPadding(0, dp(2), 0, dp(2))
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun iconFor(key: String) = when (key) { "dex" -> "✦"; "explore" -> "⌖"; "pve" -> "♜"; "battle" -> "⚔"; "league" -> "♛"; else -> "✧" }
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
