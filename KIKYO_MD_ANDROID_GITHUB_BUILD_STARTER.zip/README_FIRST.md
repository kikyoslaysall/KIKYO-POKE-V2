# KIKYO MD — Android + API starter bundle

This bundle combines the supplied Android Kotlin project with the supplied Node.js API starter. It is a buildable starting point, **not a completed live-game integration**.

## GitHub setup
1. Upload the contents of this ZIP to a new GitHub repository (keep the `KikyoMD_Android_Starter/`, `backend/`, `.github/`, and `music/` paths).
2. In repository Settings → Secrets and variables → Actions, add `KIKYO_API_BASE_URL` with your public HTTPS API origin, e.g. `https://api.example.com` (no `/api/v1` suffix). Never add Pterodactyl panel keys to the APK or repository.
3. Push to `main`/`master` or run Actions → Build KIKYO MD APK. Download the `kikyo-md-debug-apk` artifact. It is a debug APK, not a Play Store signed release.
4. To build locally, install JDK 17, Android SDK and Gradle; from `KikyoMD_Android_Starter` run `gradle assembleDebug -PAPI_BASE_URL=https://your-api-domain`.

## Pterodactyl deployment
- Deploy `backend/` as its own Node.js 20+ server/service with startup command `npm start` and allocation port exposed as `PORT`.
- Use persistent storage for `backend/data/store.json`; back it up before redeploying.
- Put the API behind HTTPS using your host's supported reverse proxy/domain. The health check is `GET /health`.
- Run the WhatsApp bot as a separate Pterodactyl server/service (or a separately supervised process if your host explicitly supports it). Do not run two long-lived processes in one container unless the startup/supervisor is designed for it. The Android app is installed on phones and is not deployed in Pterodactyl.

## Important limitations
- The supplied backend intentionally rejects OTP login because no trusted OTP provider/account lookup was supplied. It has no connection to the WhatsApp bot's player database.
- Game actions, battles, PvE, raids, league, shared inventory and player sync remain unimplemented. API placeholder responses are not real game data.
- Do not point the app at the Pterodactyl panel URL. Point it at the separate public HTTPS API service.
- The `app/src/main/assets/music/` folder is where you can add audio files you own/license. The player UI/player engine is not implemented yet; adding files alone will not make music play.
- Splash and page transition animations are included.
